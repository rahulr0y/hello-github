import java.util.Scanner;

public class Implementation {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        BusinessLogic log = new BusinessLogic();
        log.launchApplication();
    }
}
